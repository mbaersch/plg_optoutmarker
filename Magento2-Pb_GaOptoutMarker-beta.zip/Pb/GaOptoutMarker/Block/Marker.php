<?php
/**
 * GA Opt-Out-Marker
 * Description: Ausgabe eines Markers f&uuml;r internen Traffic zum Ausschluss aus Google Analytics. Weitere Infos siehe Blog 
 *
 * @category    Mage
 * @package     Pb_GaOptoutMarker
 * @copyright   Copyright (c) 2017 Markus Baersch, gandke marketing & software (http://www.gandke.de), Peter Berghausen (http://www.peterberghausen.de/)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Pb\GaOptoutMarker\Block;

/**
 * GoogleAnalitics Page Block
 *
 * @category   Mage
 * @package    Pb_GaOptoutMarker
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Marker extends \Magento\Framework\View\Element\Template
{
    protected $_gaOptoutMarkerData = null;
	
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Pb\GaOptoutMarker\Helper\Data $gaOptoutMarkerData,
        array $data = []
    ) {
        $this->_gaOptoutMarkerData = $gaOptoutMarkerData;
        parent::__construct($context, $data);
    }

    /**
     * Get config
     *
     * @param string $path
     * @return mixed
     */
    public function getConfig($path)
    {
        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
	
    /**
     * Render GA tracking scripts
     *
     * @return string
     */
    protected function _toHtml()
    {
        if (!$this->_gaOptoutMarkerData->isPbGaOptoutMarkerAvailable()) {
            return '';
        }
        return parent::_toHtml();
    }
}