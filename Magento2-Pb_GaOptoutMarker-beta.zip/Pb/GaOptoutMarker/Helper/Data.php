<?php
/**
 * GA Opt-Out-Marker
 * Description: Ausgabe eines Markers f&uuml;r internen Traffic zum Ausschluss aus Google Analytics. Weitere Infos siehe Blog 
 *
 * @category    Mage
 * @package     Pb_GaOptoutMarker
 * @copyright   Copyright (c) 2017 Markus Baersch, gandke marketing & software (http://www.gandke.de), Peter Berghausen (http://www.peterberghausen.de/)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


namespace Pb\GaOptoutMarker\Helper;

use Magento\Store\Model\Store;
/**
 * PbGaOptoutMarker data helper
 *
 * @category   Pb
 * @package    Pb_GaOptoutMarker
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * Config paths for using throughout the code
     */
    const PB_GA_OUTPUT_MARKER_PATTERN       = 'gaoptoutmarkerconfig/gaoptoutmarkergroup/pattern';
    const PB_GA_OUTPUT_MARKER_HEADERNAME    = 'gaoptoutmarkerconfig/gaoptoutmarkergroup/headername';
    const PB_GA_OUTPUT_MARKER_HEADERVALUE 	= 'gaoptoutmarkerconfig/gaoptoutmarkergroup/headervalue';
    const PB_GA_OUTPUT_MARKER_ECHOTEXT 		= 'gaoptoutmarkerconfig/gaoptoutmarkergroup/echotext';
	
    /**
     * Ausgeben, wenn Bedingung zutrifft
     *
     * @param mixed $store
     * @return bool
     */
    public function isPbGaOptoutMarkerAvailable()
    {
    	$return = false;
		/*echo $this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_ECHOTEXT).'<br />';
		echo $this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_PATTERN).'<br />';
		echo $this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_HEADERVALUE).'<br />';*/
		//echo $this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_HEADERNAME).'<br />';
		//if( isset($_SERVER[$this->scopeConfig->getValue((string)self::PB_GA_OUTPUT_MARKER_HEADERNAME)]) ) echo $_SERVER[(string)$this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_HEADERNAME)].'<br />';
		if ((($this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_PATTERN) != "") && (preg_match("/".$this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_PATTERN)."/i", $_SERVER['REMOTE_ADDR']))) 
				|| (($this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_HEADERNAME) != "") && isset($_SERVER[$this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_HEADERNAME)])
						&& ($_SERVER[$this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_HEADERNAME)] === $this->scopeConfig->getValue(self::PB_GA_OUTPUT_MARKER_HEADERVALUE))))  {
        	$return = true;
		}
        return $return;
    }
}