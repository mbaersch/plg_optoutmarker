<?php

class Shopware_Plugins_Frontend_PbGaOptoutMarker_Bootstrap extends Shopware_Components_Plugin_Bootstrap
{
    private $pluginInfo = array(
        'label' => 'GA Opt-Out-Marker',
        'version' => '1.0.0',
        'autor' => 'Markus Baersch, gandke marketing & software, Peter Berghausen',
        'supplier' => 'Peter Berghausen',
        'support' => 'mail@peterberghausen.de',
        'copyright' => 'Copyright (c) __DATE__, Markus Baersch, gandke marketing & software, Peter Berghausen',
        'link' => 'http://www.peterberghausen.de',
        'description' => '<p>
            <a href="http://www.peterberghausen.de" target="_blank">
                <img style="border: none" src="http://www.peterberghausen.de/lib/img/logo.png" alt="Peter Berghausen - IT-Entwicklung und -Beratung">
            </a>
        </p>
        <p style="margin-top:15px;color:#000;font-weight:bold">
        	Ausgabe eines Markers f&uuml;r internen Traffic zum Ausschluss aus Google Analytics. Weitere Infos siehe Blog
        	Markus Baersch, gandke marketing & software<br />
            Peter Berghausen - IT-Entwicklung und -Beratung<br />
        </p>
        <p style="margin-top:15px">
        </p>',
    );

    private $pluginCapabilities = array(
        'install' => true,
        'enable' => true,
        'update' => true
    );

    public function getVersion()
    {
        return $this->pluginInfo['version'];
    }

    public function getLabel()
    {
        return $this->pluginInfo['label'];
    }

    public function getInfo()
    {
        $this->pluginInfo['description'] = str_replace('__DATE__', date('Y'), $this->pluginInfo['description']);
        $this->pluginInfo['copyright'] = str_replace('__DATE__', date('Y'), $this->pluginInfo['copyright']);
        return $this->pluginInfo;
    }

    public function getCapabilities()
    {
        return $this->pluginCapabilities;
    }

    public function install()
    {
        try {
            $this->addEvents();
            $this->createPluginConfig();
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }

        return array(
            'success'         => true,
            'invalidateCache' => array(
                'backend',
                'config',
                'template'
            )
        );
    }

    public function uninstall()
    {
        return array(
            'success'         => true,
            'invalidateCache' => array(
                'backend',
                'config',
                'template'
            )
        );
    }

    public function enable()
    {
        return array(
            'success'         => true,
            'invalidateCache' => array(
                'template',
            )
        );
    }

    public function disable()
    {
        return array(
            'success'         => true,
            'invalidateCache' => array(
                'template',
            )
        );
    }

    private function addEvents()
    {
        $this->subscribeEvent('Enlight_Controller_Action_PostDispatch_Frontend', 'onControllerActionPostDispatchFrontend');
    }

    public function onControllerActionPostDispatchFrontend(Enlight_Event_EventArgs $args)
    {
        $controller     = $args->getSubject();
        $view           = $controller->View();

        $view->addTemplateDir($this->Path() . 'Views/');

        $view->pb_ga_optout_marker_pattern = $this->Config()->get('pb_ga_optout_marker_pattern');
        $view->pb_ga_optout_marker_headername = $this->Config()->get('pb_ga_optout_marker_headername');
        $view->pb_ga_optout_marker_headervalue = $this->Config()->get('pb_ga_optout_marker_headervalue');
        $view->pb_ga_optout_marker_echotext = $this->Config()->get('pb_ga_optout_marker_echotext');
		
		if ((($view->pb_ga_optout_marker_pattern != "") && (preg_match("/".$view->pb_ga_optout_marker_pattern."/i", $_SERVER['REMOTE_ADDR']))) 
				|| (($view->pb_ga_optout_marker_headername != "") && ($_SERVER[$view->pb_ga_optout_marker_headername] === $view->pb_ga_optout_marker_headervalue)))  {
        	//echo '<script type="text/javascript">'.$view->pb_ga_optout_marker_echotext.'</script>'.PHP_EOL;
        	$view->extendsTemplate('PbGaOptoutMarker/frontend/index/header.tpl');
		}
    }

    private function createPluginConfig()
    {
        $form = $this->Form();

        $form->setElement('text', 'pb_ga_optout_marker_pattern', array(
            'label'    => 'IP-Filtermuster',
            'required' => true,
            'scope'    => Shopware\Models\Config\Element::SCOPE_SHOP
        )); //^127\.0\.0\.1$
        $form->setElement('text', 'pb_ga_optout_marker_headername', array(
            'label'    => 'Header-Name',
            'required' => true,
            'scope'    => Shopware\Models\Config\Element::SCOPE_SHOP
        )); //HTTP_GA_TRAFFIC_TYPE
        $form->setElement('text', 'pb_ga_optout_marker_headervalue', array(
            'label'    => 'Header-Wert',
            'required' => true,
            'scope'    => Shopware\Models\Config\Element::SCOPE_SHOP
        )); //Intern
        $form->setElement('text', 'pb_ga_optout_marker_echotext', array(
            'label'    => 'Text für Ausgabe',
            'required' => true,
            'scope'    => Shopware\Models\Config\Element::SCOPE_SHOP
        )); //var gaDim1Value='intern';        
    }
}