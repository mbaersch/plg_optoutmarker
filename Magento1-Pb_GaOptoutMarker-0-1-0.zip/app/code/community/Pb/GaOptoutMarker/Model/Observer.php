<?php
/**
 * GA Opt-Out-Marker
 * Description: Ausgabe eines Markers f&uuml;r internen Traffic zum Ausschluss aus Google Analytics. Weitere Infos siehe Blog 
 *
 * @category    Mage
 * @package     Pb_GaOptoutMarker
 * @copyright   Copyright (c) 2017 Markus Baersch, gandke marketing & software (http://www.gandke.de), Peter Berghausen (http://www.peterberghausen.de/)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * GA Opt-Out-Marker module observer
 *
 * @category   Mage
 * @package    Pb_GaOptoutMarker
 */
class Pb_GaOptoutMarker_Model_Observer
{
	//Nothing to do
}
