<?php
/**
 * GA Opt-Out-Marker
 * Description: Ausgabe eines Markers f&uuml;r internen Traffic zum Ausschluss aus Google Analytics. Weitere Infos siehe Blog 
 *
 * @category    Mage
 * @package     Pb_GaOptoutMarker
 * @copyright   Copyright (c) 2017 Markus Baersch, gandke marketing & software (http://www.gandke.de), Peter Berghausen (http://www.peterberghausen.de/)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * PbGaOptoutMarker data helper
 *
 * @category   Pb
 * @package    Pb_GaOptoutMarker
 */
class Pb_GaOptoutMarker_Helper_Data extends Mage_Core_Helper_Abstract
{
    /**
     * Config paths for using throughout the code
     */
    const PB_GA_OUTPUT_MARKER_PATTERN       = 'gaoptoutmarkerconfig/gaoptoutmarkergroup/pattern';
    const PB_GA_OUTPUT_MARKER_HEADERNAME    = 'gaoptoutmarkerconfig/gaoptoutmarkergroup/headername';
    const PB_GA_OUTPUT_MARKER_HEADERVALUE 	= 'gaoptoutmarkerconfig/gaoptoutmarkergroup/headervalue';
    const PB_GA_OUTPUT_MARKER_ECHOTEXT 		= 'gaoptoutmarkerconfig/gaoptoutmarkergroup/echotext';
	
    /**
     * Ausgeben, wenn Bedingung zutrifft
     *
     * @param mixed $store
     * @return bool
     */
    public function isPbGaOptoutMarkerAvailable()
    {
    	$return = false;
		if (((Mage::getStoreConfig(self::PB_GA_OUTPUT_MARKER_PATTERN) != "") && (preg_match("/".Mage::getStoreConfig(self::PB_GA_OUTPUT_MARKER_PATTERN)."/i", $_SERVER['REMOTE_ADDR']))) 
				|| ((Mage::getStoreConfig(self::PB_GA_OUTPUT_MARKER_HEADERNAME) != "") && ($_SERVER[Mage::getStoreConfig(self::PB_GA_OUTPUT_MARKER_HEADERNAME)] === Mage::getStoreConfig(self::PB_GA_OUTPUT_MARKER_HEADERVALUE))))  {
        	$return = true;
		}
        return $return;
    }
}
