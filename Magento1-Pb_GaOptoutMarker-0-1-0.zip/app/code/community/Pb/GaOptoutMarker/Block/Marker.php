<?php
/**
 * GA Opt-Out-Marker
 * Description: Ausgabe eines Markers f&uuml;r internen Traffic zum Ausschluss aus Google Analytics. Weitere Infos siehe Blog 
 *
 * @category    Mage
 * @package     Pb_GaOptoutMarker
 * @copyright   Copyright (c) 2017 Markus Baersch, gandke marketing & software (http://www.gandke.de), Peter Berghausen (http://www.peterberghausen.de/)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * GoogleAnalitics Page Block
 *
 * @category   Mage
 * @package    Pb_GaOptoutMarker
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Pb_GaOptoutMarker_Block_Marker extends Mage_Core_Block_Template
{
    /**
     * Render GA tracking scripts
     *
     * @return string
     */
    protected function _toHtml()
    {
        if (!Mage::helper('gaoptoutmarker/data')->isPbGaOptoutMarkerAvailable()) {
            return '';
        }
        return parent::_toHtml();
    }
}
