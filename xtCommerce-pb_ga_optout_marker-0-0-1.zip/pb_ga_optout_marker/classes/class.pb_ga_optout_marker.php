<?php
/**
 * Modul: pb_ga_optout_marker
 * Author:    Markus Baersch, gandke marketing & software, Peter Berghausen | http://www.gandke.de, http://www.peterberghausen.de
 * File: class.pb_ga_optout_marker.php
 */

defined('_VALID_CALL') or die('Direct Access is not allowed.');

class pb_ga_optout_marker {

	function hook_ga_optout() {
		if (((PB_GA_OUTPUT_MARKER_PATTERN != "") && (preg_match("/".PB_GA_OUTPUT_MARKER_PATTERN."/i", $_SERVER['REMOTE_ADDR']))) || ((PB_GA_OUTPUT_MARKER_HEADERNAME != "") && ($_SERVER[PB_GA_OUTPUT_MARKER_HEADERNAME] === PB_GA_OUTPUT_MARKER_HEADERVALUE)))  {
        	echo '<script type="text/javascript">'.PB_GA_OUTPUT_MARKER_ECHOTEXT.'</script>'.PHP_EOL;
		}
		return $return;
	}
}